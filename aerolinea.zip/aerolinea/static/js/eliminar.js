// ================================================================
//  AeroLista ✈ · eliminar.js — cancelar una reserva
// ================================================================

// Abre la ventana <dialog> y ESPERA la respuesta del usuario.
// Retorna una promesa que se cumple con true (Sí) o false (No).
function preguntar(titulo, texto) {
  const modal = $("#modal");
  const formulario = modal.querySelector("form");
  $("#modal-titulo").textContent = titulo;
  $("#modal-texto").textContent = texto;
  modal.returnValue = "no";

  return new Promise((resolver) => {
    // Registramos el evento ANTES de abrir el diálogo para no perder el cierre.
    modal.addEventListener("close", () => {
      resolver(modal.returnValue === "si");
    }, { once: true });
    modal.showModal();
  });
}

// Pregunta y, si el usuario acepta, elimina. Retorna true si se eliminó.
// pasajero es opcional: si lo tenemos, mostramos su nombre en la pregunta.
async function confirmarEliminar(numero, pasajero = null) {
  const numeroReserva = Number(numero);
  if (!Number.isInteger(numeroReserva) || numeroReserva <= 0) {
    avisar("Selecciona una reserva válida para cancelar.", "error");
    return false;
  }

  const quien = pasajero
    ? `${pasajero.nombre} (asiento ${pasajero.asiento})`
    : `la reserva #${numeroReserva}`;
  const acepta = await preguntar("¿Cancelar la reserva?",
    `Se quitará a ${quien} y el asiento quedará libre.`);
  if (!acepta) return false;

  try {
    const r = await API.eliminar(numeroReserva);
    if (!r.ok) {
      mostrarProblema(r);
      return false;
    }

    // Actualizamos la interfaz inmediatamente después de confirmar el éxito del servidor.
    estado.encontrado = null;
    if (estado.enEdicion && estado.enEdicion.numero === numeroReserva) cancelarEdicion();
    $("#eliminar-numero").value = "";
    if ($("#resultado-buscar")) $("#resultado-buscar").innerHTML = "";
    await refrescar();
    avisar(r.mensaje || `Reserva #${numeroReserva} cancelada correctamente.`, "ok");
    animarAsiento(r.datos.asiento, "liberado");
    return true;
  } catch (error) {
    console.error("Error al cancelar la reserva:", error);
    avisar("No se pudo completar la cancelación. Revisa que Flask siga encendido.", "codigo");
    return false;
  }
}

// Al enviar el formulario de la pestaña Eliminar
async function enviarEliminar(evento) {
  evento.preventDefault();
  await confirmarEliminar($("#eliminar-numero").value);
}

$("#form-eliminar").addEventListener("submit", enviarEliminar);
