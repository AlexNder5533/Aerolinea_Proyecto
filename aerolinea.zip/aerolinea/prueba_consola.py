# ==============================================================
#  prueba_consola.py · Prueba los 9 métodos de ListaPasajeros
#  Ejecuta: python prueba_consola.py
# ==============================================================
from lista_pasajeros import ListaPasajeros
from pasajero import Pasajero

lista = ListaPasajeros()

# 1. esta_vacia
assert lista.esta_vacia() is True

# ingresar (método entregado) y 2. longitud
lista.ingresar(Pasajero(1005, "Diana", "0923456789", 22, "3C"))
lista.ingresar(Pasajero(1002, "Ana", "0912345678", 28, "1A"))
lista.ingresar(Pasajero(1009, "Luis", "0987654321", 35, "7D"))
lista.ingresar(Pasajero(1004, "Beto", "0934567890", 16, "7E"))
assert lista.esta_vacia() is False
assert lista.longitud() == 4

# 3. listar
assert [p.nombre for p in lista.listar()] == ["Diana", "Ana", "Luis", "Beto"]

# 4. buscar
assert lista.buscar(1009).nombre == "Luis"
assert lista.buscar(9999) is None

# 5. buscar_por_asiento
assert lista.buscar_por_asiento(" 7e ").nombre == "Beto"
assert lista.buscar_por_asiento("12A") is None

# 6. buscar_por_cedula
assert lista.buscar_por_cedula("0923456789").nombre == "Diana"
assert lista.buscar_por_cedula("0000000000") is None

# 7. modificar
assert lista.modificar(1009, "Luis A.", 36, "9f") is True
assert lista.buscar(1009).edad == 36
assert lista.buscar(1009).asiento == "9F"
assert lista.modificar(9999, "Nadie", 20, "1B") is False

# 8. filtrar_por_clase
assert [p.nombre for p in lista.filtrar_por_clase("Ejecutiva")] == ["Ana"]
assert [p.nombre for p in lista.filtrar_por_clase("Económica")] == ["Diana", "Luis A.", "Beto"]

# 9. eliminar: cabeza, nodo intermedio/final y número inexistente
assert lista.eliminar(1005).nombre == "Diana"
assert lista.eliminar(9999) is None
assert lista.eliminar(1002).nombre == "Ana"
assert lista.eliminar(1004).nombre == "Beto"
assert lista.eliminar(1009).nombre == "Luis A."
assert lista.esta_vacia() is True
assert lista.longitud() == 0

print("¡Correcto! Los 9 métodos de la lista enlazada pasaron todas las pruebas.")
